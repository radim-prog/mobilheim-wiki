# 🏠 Mobilheim Wiki - Notion Import (v2)

**Vylepšená verze s rozděleným FAQ!**

---

## ✨ Co je nové v V2?

**FAQ rozdělené na 7 samostatných souborů:**
- Místo jednoho dlouhého dokumentu (1472 řádků)
- 7 přehledných kategorií (každá samostatně)
- Jednodušší navigace v Notionu

---

## 📂 Struktura

### 📖 Wiki (29 článků)
Komplexní znalostní báze

### ✍️ Blog (25 článků)
Profesionální články

### ❓ FAQ (7 kategorií = 7 souborů)
1. Legislativa a povolení (20 otázek)
2. Náklady a financování (18 otázek)
3. Technické otázky (22 otázek)
4. Výběr a nákup (15 otázek)
5. Provoz a údržba (12 otázek)
6. Praktické záležitosti (15 otázek)
7. Speciální situace (10 otázek)

**Celkem: 112 otázek**

---

## 📝 Poznámky v Notionu

1. **Označte text**
2. Klikněte na **bublinu** 💬
3. **Napište poznámku**
4. Hotovo!

---

**Mnohem přehlednější než v1!** 🚀
