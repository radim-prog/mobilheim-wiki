# 🏠 Mobilheim Wiki - Notion Import

**Kompletní wikipedie o mobilních domech**

---

## 📂 Struktura

### 📖 Wiki (29 článků)
Komplexní znalostní báze:
- Legislativa (zákony, vyhlášky, judikatura)
- Technické specifikace (materiály, konstrukce, energetika)
- Připojení k sítím
- Financování a dotace
- Údržba a životnost
- Případové studie

### ✍️ Blog (25 článků)
Profesionální články pro širokou veřejnost:
- Základy mobilních domů
- Nákup a ceny
- Financování
- Technické informace
- Provoz a údržba

### ❓ FAQ (112 otázek)
Nejčastější dotazy rozdělené do 7 kategorií

---

## 📝 Jak používat v Notionu

### Komentáře/Poznámky
1. **Označte text** v jakémkoliv článku
2. Klikněte na **ikonu bubliny** (vpravo)
3. **Napište poznámku**
4. Hotovo! Poznámka je uložena u textu

### Sdílení se sekretářkou
1. Klikněte **"Share"** (vpravo nahoře)
2. Zadejte email sekretářky
3. Vyberte **"Can comment"**
4. Sekretářka může psát poznámky, ale ne editovat

---

## 📊 Statistiky

- **54 článků** celkem
- **~112 000 slov** v blogu
- **112 FAQ otázek**
- **100% čeština**
- Reálná data pro rok 2025

---

**Připraveno pro import do Notionu!**
