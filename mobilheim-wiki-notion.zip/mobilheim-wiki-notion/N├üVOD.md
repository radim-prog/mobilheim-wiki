# 📥 Jak naimportovat do Notionu

## Jednoduchý postup (3 minuty)

### Krok 1: Rozbal ZIP
Rozbal `mobilheim-wiki-notion.zip`

### Krok 2: Otevři Notion
Otevři svůj Notion workspace

### Krok 3: Import
1. Klikni **"Settings & members"** (vlevo dole)
2. Vyber **"Settings"** tab
3. Klikni **"Import"**
4. Vyber **"Markdown & CSV"**
5. Vyber **celou složku** `mobilheim-wiki-notion`
6. Klikni **"Import"**

### ✅ Hotovo!

Notion vytvoří:
```
📄 README (úvodní stránka)
📁 Blog (25 článků)
📁 Wiki (29 článků)
📁 FAQ (112 otázek)
```

---

## 💡 Tipy

### Poznámky
- Označit text → kliknout na bublinu → napsat poznámku
- Poznámky vidí všichni se kterými sdílíš stránku

### Organizace
- Můžeš přesouvat stránky drag & drop
- Můžeš vytvářet podsložky
- Můžeš přidávat ikony a obálky

### Sdílení
- **Can view** = jen čtení
- **Can comment** = čtení + poznámky (ideální pro sekretářku)
- **Can edit** = plná editace

---

**Vše je připraveno pro okamžité použití v Notionu!** 🚀
